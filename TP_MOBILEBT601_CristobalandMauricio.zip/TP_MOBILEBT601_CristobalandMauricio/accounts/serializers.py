from rest_framework import serializers
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate

class SuperuserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        user = authenticate(username=data['username'], password=data['password'])
        if user is None or not user.is_superuser:
            raise serializers.ValidationError("Invalid credentials or not a superuser.")
        data['user'] = user
        return data

    def create(self, validated_data):
        token, _ = Token.objects.get_or_create(user=validated_data['user'])
        return token
