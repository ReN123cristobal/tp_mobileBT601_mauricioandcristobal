from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .serializers import SuperuserLoginSerializer

class SuperuserLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        serializer = SuperuserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        token = serializer.save()
        return Response({'token': token.key})

class CreatedUsersListView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        if not request.user.is_superuser:
            return Response({'detail': 'Not allowed'}, status=status.HTTP_403_FORBIDDEN)

        profiles = request.user.created_users.select_related('user')
        users = [{
            'id': p.user.id,
            'username': p.user.username,
            'email': p.user.email
        } for p in profiles]
        return Response(users)

def superuser_login_ui(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(username=username, password=password)
        if user and user.is_superuser:
            login(request, user)
            return redirect('/admin/')
        else:
            return render(request, "login.html", {"error": "Invalid credentials or not a superuser"})
    return render(request, "login.html")
