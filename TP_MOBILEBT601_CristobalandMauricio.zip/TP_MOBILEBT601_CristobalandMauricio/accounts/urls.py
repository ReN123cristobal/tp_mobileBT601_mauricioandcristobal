from django.urls import path
from .views import SuperuserLoginView, CreatedUsersListView, superuser_login_ui

urlpatterns = [
    path('login/', SuperuserLoginView.as_view(), name='superuser-login'),
    path('my-users/', CreatedUsersListView.as_view(), name='created-users'),
    path('ui-login/', superuser_login_ui, name='superuser-login-ui'),
]
